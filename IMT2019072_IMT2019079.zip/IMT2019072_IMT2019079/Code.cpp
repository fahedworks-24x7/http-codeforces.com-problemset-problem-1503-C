#include<bits/stdc++.h>
using namespace std;
//Code starts here

int main()
{
	int n;
	cin >> n;
	pair<long long int, long long int> g[n];
	long long int ans = 0;
	for( int i = 0; i < n; i++ ) cin >> g[i].first >> g[i].second;
	sort(g, g + n);
	for(int i = 0; i < n; i++ ) ans += g[i].second;
	long long int mx = g[0].first + g[0].second;
	for(int i = 0; i < n; i++ )
	{
		if( g[i].first - mx > 0 ) ans += g[i].first - mx;
		mx = max( mx, g[i].first + g[i].second );
	}
	cout << ans;
}
